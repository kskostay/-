public class Palindrome {
    public static void main(String[] args) {
        //перебор всех входных аргументов
        for (int i = 0; i < args.length; i++) {
            String s = args[i];
            //проверяем, является ли очередной аргумент палиндромом
            if (isPalindrome(s))
            // выводим на экран если является
                System.out.println(s + " является палиндромом");
        } 
    }
    
    //метод, переворачивающий строку
    public static String reverseString(String s){
        //результирующая строка
        String reverseStr = "";
        //перебор всех символов входной строки в обратном порядке (length()-1: последний символ строки, 0: первый)
        for (int i = s.length()-1; i >= 0 ; i--){
        //добавляем очередной символ к  результирующей строке
            reverseStr += s.charAt(i);
        }
        return reverseStr;
    }
    
    //метод, проверяющий, является ли входная строка палиндромом
    //true - является, false - нет
    public static boolean isPalindrome(String s){
        //переворачиваем входную строку
        String reverseS = reverseString (s);
        
        //сравниваем входную строку и перевернутую и возвращаем результат
        return s.equals(reverseS);
    }
}