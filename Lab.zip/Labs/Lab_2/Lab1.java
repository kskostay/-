import java.util.Scanner;

public class Lab1 {
  public static void main(String[] args) {
    //ввод координат трех точек
    System.out.println ("Введите через пробел координаты x y z первой точки:");
    Point3d p1 = readPoint();
    System.out.println ("Введите через пробел координаты x y z второй точки:");
    Point3d p2 = readPoint();
    System.out.println ("Введите через пробел координаты x y z третьей точки:");
    Point3d p3 = readPoint();
    
    //проверка значенй, если есть 2 одинаковые точки - вывод сообщения пользователю
    if (!p1.isEquals(p2) && !p1.isEquals(p3) && !p2.isEquals(p3)) {
      //вывод площади получнного треугольника
      System.out.println ("Площадь треугольника = " + Lab1.computeArea(p1,p2,p3));
    }
    else {
      System.out.println ("Введите корректные данные");
    }    
  }
  
  //вычисление площади треугольника по трем точкам (формула Герона)
  public static double computeArea(Point3d p1, Point3d p2, Point3d p3) {
    //расчет сторон треугольника
    double a = p1.distanceTo(p2); 
    double b = p2.distanceTo(p3);
    double c = p3.distanceTo(p1);
    //расчет полупериметра
    double semiPer = (a+b+c) / 2.0;
    //расчет площади
	double square = Math.sqrt(semiPer*(semiPer-a)*(semiPer-b)*(semiPer-c));
    return square;
  }
  
  //метод для ввода даных пользователем
  static Point3d readPoint()
  {
    Scanner console = new Scanner(System.in);
    double x = console.nextDouble();
    double y = console.nextDouble();
    double z = console.nextDouble();
    return new Point3d(x, y, z);
  }
}
